using System;
using System.Linq;
using System.Collections;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Telerik.Windows;
using Telerik.Windows.Controls.DragDrop;

namespace ListBoxDragReorder
{
	public partial class Page : UserControl
	{
		public Page()
		{
			InitializeComponent();
			var random = new Random(123123123);

			Func<int, String, IEnumerable> generator = 
				(count, itemName) => Enumerable.Range(1, count)
					.Select(num => new CheckableItemsViewModel()
					{
						Name =	String.Format("{0} {1}", itemName, num),
						IsChecked = random.Next() % 2 == 0
					})
					.Aggregate(new ObservableCollection<CheckableItemsViewModel>(), (total, next) => { total.Add(next); return total; });

			listBox1.ItemsSource = generator(30, "My Items");
			listBox2.ItemsSource = generator(5, "Other Items");
			wrappedItems.ItemsSource = generator(10, "Wrap Item");

			//NOTE: Application-specific validation has been ommited, drop may not always be possible.
			//NOTE: In this example it is assumed that the ListBoxes are bound.

			//Wire the events:
			listBox1.AddHandler(RadDragAndDropManager.DropQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnDropQuery));
			listBox1.AddHandler(RadDragAndDropManager.DragQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnDragQuery));
			listBox1.AddHandler(RadDragAndDropManager.DropInfoEvent, new EventHandler<DragDropEventArgs>(OnDropInfo));
			listBox1.AddHandler(RadDragAndDropManager.DragInfoEvent, new EventHandler<DragDropEventArgs>(OnDragInfo));

			listBox2.AddHandler(RadDragAndDropManager.DropQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnDropQuery));
			listBox2.AddHandler(RadDragAndDropManager.DragQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnDragQuery));
			listBox2.AddHandler(RadDragAndDropManager.DropInfoEvent, new EventHandler<DragDropEventArgs>(OnDropInfo));
			listBox2.AddHandler(RadDragAndDropManager.DragInfoEvent, new EventHandler<DragDropEventArgs>(OnDragInfo));

			//Wire up events for the WrapPanel, some event handlers are shared:
			wrappedItems.AddHandler(RadDragAndDropManager.DropQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnWrappedItemsDropQuery));
			wrappedItems.AddHandler(RadDragAndDropManager.DragQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnDragQuery));
			wrappedItems.AddHandler(RadDragAndDropManager.DropInfoEvent, new EventHandler<DragDropEventArgs>(OnWrappedItemsDropInfo));
			wrappedItems.AddHandler(RadDragAndDropManager.DragInfoEvent, new EventHandler<DragDropEventArgs>(OnDragInfo));
		}

		private void OnWrappedItemsDropQuery(object sender, DragDropQueryEventArgs e)
		{
			var destination = e.Options.Destination;

			if (e.Options.Status == DragStatus.DropDestinationQuery && destination is ContentPresenter)
			{
				var listBox = destination.FindItemsConrolParent() as ItemsControl;

				//Cannot place na item relative to itself:
				if (e.Options.Source == e.Options.Destination)
				{
					return;
				}

				//Get the spatial relation between the destination item and the vis. root:
				var destinationTopLeft = destination.TransformToVisual(null).Transform(new Point());

				var operation = e.Options.Payload as DragDropOperation;

				e.QueryResult = true;
				e.Handled = true;
			}

			if (e.Options.Status == DragStatus.DropDestinationQuery && destination is ListBox)
			{
				var listBox = destination as ItemsControl;

				// Cannot drop the last or only item of the list box within the same list box:

				var operation = e.Options.Payload as DragDropOperation;

				if (listBox.ItemsSource != null && listBox.ItemsSource.Cast<object>().Last() != operation.Payload)
				{
					e.QueryResult = true;
					e.Handled = true;
				}
				else
				{
					e.QueryResult = false;
					e.Handled = true;
				}
			}
		}

		private void OnWrappedItemsDropInfo(object sender, DragDropEventArgs e)
		{
			var destination = e.Options.Destination;

			//Place the item:
			if (e.Options.Status == DragStatus.DropComplete && destination is ContentPresenter)
			{
				var itemsControl = e.Options.Destination.FindItemsConrolParent() as ItemsControl;

				var itemsSource = itemsControl.ItemsSource as IList;
				var destinationIndex = itemsSource.IndexOf(e.Options.Destination.DataContext);

				var operation = e.Options.Payload as DragDropOperation;
				var insertIndex = destinationIndex;

				itemsSource.Insert(insertIndex, operation.Payload);
			}
		}

		private void OnDragInfo(object sender, DragDropEventArgs e)
		{
			if (e.Options.Status == DragStatus.DragComplete)
			{
				var listBox = e.Options.Source.FindItemsConrolParent() as ItemsControl;

				var itemsSource = listBox.ItemsSource as IList;
				var operation = e.Options.Payload as DragDropOperation;

				itemsSource.Remove(operation.Payload);
			}
		}

		private void OnDropInfo(object sender, DragDropEventArgs e)
		{
			var destination = e.Options.Destination;

			if (e.Options.Status == DragStatus.DropPossible && destination is ListBoxItem)
			{
				var listBox = destination.FindItemsConrolParent() as ListBox;
				VisualStateManager.GoToState(listBox, "DropPossible", false);

				//Get the DropCueElemet:
				var dropCueElement = (VisualTreeHelper.GetChild(listBox, 0) as FrameworkElement).FindName("DropCueElement") as FrameworkElement;

				var operation = e.Options.Payload as DragDropOperation;

				//Get the parent of the destination:
				var visParent = VisualTreeHelper.GetParent(destination) as UIElement;

				//Get the spacial relation between the destination and its parent:
				var destinationStackTopLeft = destination.TransformToVisual(visParent).Transform(new Point());

				var yTranslateValue = operation.DropPosition == DropPosition.Before ? destinationStackTopLeft.Y : destinationStackTopLeft.Y + destination.ActualHeight;

				dropCueElement.RenderTransform = new TranslateTransform() { Y = yTranslateValue };

				e.Handled = true;
			}

			if (e.Options.Status == DragStatus.DropPossible && destination is ListBox)
			{
				var listBox = destination as ListBox;
				VisualStateManager.GoToState(listBox, "DropPossible", false);

				//Get the DropCueElemet:
				var dropCueElement = (VisualTreeHelper.GetChild(listBox, 0) as FrameworkElement).FindName("DropCueElement") as FrameworkElement;

				var operation = e.Options.Payload as DragDropOperation;

				// Get the size of the items:
				var itemsPresenter = listBox.GetTemplateChild<FrameworkElement>("ItemsPresenterElement");
				var panel = VisualTreeHelper.GetChild(itemsPresenter, 0) as Panel;

				if (panel != null)
				{
					var yTranslateValue = panel.ActualHeight;
					dropCueElement.RenderTransform = new TranslateTransform() { Y = yTranslateValue };
				}
			}

			//Hide the DropCue:
			if (e.Options.Status == DragStatus.DropImpossible || e.Options.Status == DragStatus.DropCancel || e.Options.Status == DragStatus.DropComplete)
			{
				var listBox = destination as ListBox;

				if (listBox == null)
				{
					listBox = e.Options.Destination.FindItemsConrolParent() as ListBox;
				}

				VisualStateManager.GoToState(listBox, "DropImpossible", false);
			}

			//Place the item:
			if (e.Options.Status == DragStatus.DropComplete && destination is ListBoxItem)
			{
				var listBox = e.Options.Destination.FindItemsConrolParent() as ListBox;
				
				var itemsSource = listBox.ItemsSource as IList;
				var destinationIndex = itemsSource.IndexOf(e.Options.Destination.DataContext);

				var operation = e.Options.Payload as DragDropOperation;
				var insertIndex = operation.DropPosition == DropPosition.Before ? destinationIndex : destinationIndex + 1;

				itemsSource.Insert(insertIndex, operation.Payload);

				listBox.Dispatcher.BeginInvoke(() => 
					{
						listBox.SelectedIndex = insertIndex;
					});

			}
		}

		private void OnDropQuery(object sender, DragDropQueryEventArgs e)
		{
			var destination = e.Options.Destination;

			if (e.Options.Status == DragStatus.DropDestinationQuery && destination is ListBoxItem)
			{
				var listBox = destination.FindItemsConrolParent() as ListBox;

				//Cannot place na item relative to itself:
				if (e.Options.Source == e.Options.Destination)
				{
					return;
				}

				//Get the spatial relation between the destination item and the vis. root:
				var destinationTopLeft = destination.TransformToVisual(null).Transform(new Point());

				//Should the new Item be moved before or after the destination item?:
				bool placeBefore = (e.Options.CurrentDragPoint.Y - destinationTopLeft.Y) < destination.ActualHeight / 2;

				var operation = e.Options.Payload as DragDropOperation;

				operation.DropPosition = placeBefore ? DropPosition.Before : DropPosition.After;

				e.QueryResult = true;
				e.Handled = true;
			}

			if (e.Options.Status == DragStatus.DropDestinationQuery && destination is ListBox)
			{
				var listBox = destination as ListBox;

				// Cannot drop the last or only item of the list box within the same list box:

				var operation = e.Options.Payload as DragDropOperation;

				if (listBox.ItemsSource != null && listBox.ItemsSource.Cast<object>().Last() != operation.Payload)
				{
					e.QueryResult = true;
					e.Handled = true;
				}
				else
				{
					e.QueryResult = false;
					e.Handled = true;
				}
			}
		}

		private void OnDragQuery(object sender, DragDropQueryEventArgs e)
		{
			if (e.Options.Status == DragStatus.DragQuery)
			{
				var sourceControl = e.Options.Source;

				e.QueryResult = true;
				e.Handled = true;

				var dragCue = RadDragAndDropManager.GenerateVisualCue(sourceControl);
				dragCue.HorizontalAlignment = HorizontalAlignment.Left;
				dragCue.Content = sourceControl.DataContext;
				e.Options.DragCue = dragCue;

				e.Options.Payload = new DragDropOperation() { Payload = sourceControl.DataContext };
			}

			if (e.Options.Status == DragStatus.DropSourceQuery)
			{
				e.QueryResult = true;
				e.Handled = true;
			}
		}
	}
}
