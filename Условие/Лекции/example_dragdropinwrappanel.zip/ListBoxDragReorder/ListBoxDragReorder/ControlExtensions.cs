﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using RadItemsControl = Telerik.Windows.Controls.ItemsControl;
using System;

namespace ListBoxDragReorder
{
	public static class ControlExtensions
	{
		public static ItemsControl FindItemsConrolParent(this FrameworkElement target)
		{
			ItemsControl result = null;
			result = target.Parent as ItemsControl;
			if (result != null)
			{
				return result;
			}

			result = RadItemsControl.ItemsControlFromItemContainer(target);
			if (result != null)
			{
				return result;
			}

			return FindVisualParent<ItemsControl>(target);
		}

		public static T FindVisualParent<T>(FrameworkElement target) where T : FrameworkElement
		{
			if (target == null)
			{
				return null;
			}
			var visParent = VisualTreeHelper.GetParent(target);
			var result = visParent as T;
			if (result != null)
			{
				return result;
			}
			return FindVisualParent<T>(visParent as FrameworkElement);
		}

		/// <summary>
		/// Acts similarly to GetTemplateChild, use sparingly, GetTemplateChild is protected for a reason.
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="target"></param>
		/// <returns></returns>
		public static T GetTemplateChild<T>(this Control target, string templtePartName) where T:FrameworkElement
		{
			if (target == null)
			{
				throw new ArgumentNullException("target", "Cannot get the templtae child of a null object");
			}

			var childCount = VisualTreeHelper.GetChildrenCount(target);
			if (childCount == 0)
			{
				return null;
			}

			return (VisualTreeHelper.GetChild(target, 0) as FrameworkElement).FindName(templtePartName) as T;
		}
	}
}
