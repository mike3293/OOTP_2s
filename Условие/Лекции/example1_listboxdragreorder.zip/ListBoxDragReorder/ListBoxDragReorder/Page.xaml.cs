using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Telerik.Windows;
using Telerik.Windows.Controls.DragDrop;

namespace ListBoxDragReorder
{
	public partial class Page : UserControl
	{
		public Page()
		{
			InitializeComponent();

			Func<String, IEnumerable> generator = (itemName) => Enumerable.Range(1, 30).Select(num => String.Format("{0} {1}", itemName, num)).Aggregate(new ObservableCollection<String>(), (total, next) => { total.Add(next); return total; });

			listBox1.ItemsSource = generator("My Items");
			listBox2.ItemsSource = generator("Other Items");


			//NOTE: Application-specific validation has been ommited, drop may not always be possible.
			//NOTE: In this example it is assumed that the ListBoxes are bound.

			//Wire the events:
			listBox1.AddHandler(RadDragAndDropManager.DropQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnDropQuery));
			listBox1.AddHandler(RadDragAndDropManager.DragQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnDragQuery));
			listBox1.AddHandler(RadDragAndDropManager.DropInfoEvent, new EventHandler<DragDropEventArgs>(OnDropInfo));
			listBox1.AddHandler(RadDragAndDropManager.DragInfoEvent, new EventHandler<DragDropEventArgs>(OnDragInfo));

			listBox2.AddHandler(RadDragAndDropManager.DropQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnDropQuery));
			listBox2.AddHandler(RadDragAndDropManager.DragQueryEvent, new EventHandler<DragDropQueryEventArgs>(OnDragQuery));
			listBox2.AddHandler(RadDragAndDropManager.DropInfoEvent, new EventHandler<DragDropEventArgs>(OnDropInfo));
			listBox2.AddHandler(RadDragAndDropManager.DragInfoEvent, new EventHandler<DragDropEventArgs>(OnDragInfo));
		}

		private void OnDragInfo(object sender, DragDropEventArgs e)
		{
			if (e.Options.Status == DragStatus.DragComplete)
			{
				var listBox = e.Options.Source.FindItemsConrolParent() as ListBox;

				var itemsSource = listBox.ItemsSource as IList;
				var operation = e.Options.Payload as DragDropOperation;

				itemsSource.Remove(operation.Payload);
			}
		}

		private void OnDropInfo(object sender, DragDropEventArgs e)
		{
			if (e.Options.Status == DragStatus.DropPossible)
			{
				var listBox = e.Options.Destination.FindItemsConrolParent() as ListBox;
				VisualStateManager.GoToState(listBox, "DropPossible", false);
				var destination = e.Options.Destination;

				//Get the DropCueElemet:
				var dropCueElement = (VisualTreeHelper.GetChild(listBox, 0) as FrameworkElement).FindName("DropCueElement") as FrameworkElement;

				var operation = e.Options.Payload as DragDropOperation;

				//Get the parent of the destination:
				var visParent = VisualTreeHelper.GetParent(destination) as UIElement;

				//Get the spacial relation between the destination and its parent:
				var destinationStackTopLeft = destination.TransformToVisual(visParent).Transform(new Point());

				var yTranslateValue = operation.DropPosition == DropPosition.Before ? destinationStackTopLeft.Y : destinationStackTopLeft.Y + destination.ActualHeight;

				dropCueElement.RenderTransform = new TranslateTransform() { Y = yTranslateValue };
			}

			//Hide the DropCue:
			if (e.Options.Status == DragStatus.DropImpossible || e.Options.Status == DragStatus.DropCancel || e.Options.Status == DragStatus.DropComplete)
			{
				var listBox = e.Options.Destination.FindItemsConrolParent() as ListBox;
				VisualStateManager.GoToState(listBox, "DropImpossible", false);
			}

			//Place the item:
			if (e.Options.Status == DragStatus.DropComplete)
			{
				var listBox = e.Options.Destination.FindItemsConrolParent() as ListBox;
				
				var itemsSource = listBox.ItemsSource as IList;
				var destinationIndex = itemsSource.IndexOf(e.Options.Destination.DataContext);

				var operation = e.Options.Payload as DragDropOperation;
				var insertIndex = operation.DropPosition == DropPosition.Before ? destinationIndex : destinationIndex + 1;

				itemsSource.Insert(insertIndex, operation.Payload);

				listBox.Dispatcher.BeginInvoke(() => 
					{
						listBox.SelectedIndex = insertIndex;
					});

			}
		}

		private void OnDropQuery(object sender, DragDropQueryEventArgs e)
		{
			if (e.Options.Status == DragStatus.DropDestinationQuery)
			{
				var destination = e.Options.Destination;
				var listBox = destination.FindItemsConrolParent() as ListBox;

				//Cannot place na item relative to itself:
				if (e.Options.Source == e.Options.Destination)
				{
					return;
				}

				VisualStateManager.GoToState(listBox, "DropPossible", false);
				
				//Get the spacial relation between the destination item and the vis. root:
				var destinationTopLeft = destination.TransformToVisual(null).Transform(new Point());

				//Should the new Item be moved before or after the destination item?:
				bool placeBefore = (e.Options.CurrentDragPoint.Y - destinationTopLeft.Y) < destination.ActualHeight / 2;

				var operation = e.Options.Payload as DragDropOperation;

				operation.DropPosition = placeBefore ? DropPosition.Before : DropPosition.After;

				e.QueryResult = true;
				e.Handled = true;
			}
		}

		private void OnDragQuery(object sender, DragDropQueryEventArgs e)
		{
			if (e.Options.Status == DragStatus.DragQuery)
			{
				e.QueryResult = true;
				e.Handled = true;

				var sourceControl = e.Options.Source;

				var dragCue = RadDragAndDropManager.GenerateVisualCue(sourceControl);
				dragCue.HorizontalAlignment = HorizontalAlignment.Left;
				dragCue.Content = sourceControl.DataContext;
				e.Options.DragCue = dragCue;

				e.Options.Payload = new DragDropOperation() { Payload = sourceControl.DataContext };
			}

			if (e.Options.Status == DragStatus.DropSourceQuery)
			{
				e.QueryResult = true;
				e.Handled = true;
			}
		}
	}
}
