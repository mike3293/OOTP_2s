﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace ListBoxDragReorder
{
	public class CheckableItemsViewModel : INotifyPropertyChanged
	{
		private bool isChecked;
		/// <summary>
		/// Gets or sets whether the item is checked.
		/// </summary>
		public bool IsChecked
		{
			get
			{
				return this.isChecked;
			}
			set
			{
				if (this.isChecked != value)
				{
					this.isChecked = value;
					OnPropertyChanged("IsChecked");
				}
			}
		}

		private String name;
		/// <summary>
		/// Gets or sets the name.
		/// </summary>
		public String Name
		{
			get
			{
				return this.name;
			}
			set
			{
				if (this.name != value)
				{
					this.name = value;
					OnPropertyChanged("Name");
				}
			}
		}

		/// <summary>
		///     Called when the value of a property changes.
		/// </summary>
		/// <param name="propertyName">The name of the property that has changed.</param>
		protected virtual void OnPropertyChanged(String propertyName)
		{
			if (String.IsNullOrEmpty(propertyName))
			{
				return;
			}
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		/// <summary>
		///     Raised when the value of one of the properties changes.
		/// </summary>
		public event PropertyChangedEventHandler PropertyChanged;
	}
}
